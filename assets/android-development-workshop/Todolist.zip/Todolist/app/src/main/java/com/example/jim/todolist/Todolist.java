package com.example.jim.todolist;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Todolist extends AppCompatActivity {

    LinearLayout noteslist;
    EditText writeArea;
    View.OnClickListener deleter;

    /**
     * Συναρτηση που τρεχει στην αρχη της εφαρμογης.
     *
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todolist);

        writeArea = findViewById(R.id.writearea);//Μεταβλητη που έχει συνδεθεί με το πεδίο που γράφει ο χρήστης
        noteslist = findViewById(R.id.mainlinear);//Μεταβλητή που συνδεεται με την λίστα που περιεχει τις σημειωσεις.

        deleter = new View.OnClickListener(){//listener που εκτελειτε σε onclick event.
            @Override
            public void onClick(View view) {
                noteslist.removeView(view);//αφαιρει την σημειωση που επιλεχτηκε απο την λίστα.
            }
        };
    }

    /**
     * Συναρτηση που εκτελειτε οταν παταμε το κουμπι add
     */
    public void CreateNote_onclick(View button)    {
        AddNote(writeArea.getText().toString());//καλει την AddNote και περναει σαν κειμενο οτι υπαρχει στο writeArea
    }

    /**
     * συναρτηση που δημιουργει μια νεα σημειωση και την προσθετει στην λιστα
     * @param text το κειμενο της σημειωσης
     */
    public void AddNote(String text){
        if(text.length()>0){//ελενχει αν το κειμενο δεν ειναι κενο
            TextView temp = new TextView(this);//δημιουργει αντικειμενο TextView
            temp.setText(text);//του προσθετει το κειμενο που δωθηκε
            temp.setTextSize(40);//μεγαλωνει το μεγεθος των γραμματων.

            temp.setClickable(true);//Κανει το αντικειμενο να μπορει να επιλεγει με click
            temp.setOnClickListener(deleter);//θετει τον OnClickListener στον deleter που φτιαξαμε πιο πανω

            noteslist.addView(temp);//τελος προσθετει το αντικειμενο στη λίστα.
        }
    }
}
